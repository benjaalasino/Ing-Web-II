# 06 — budgets.html

## Propósito
Permite al usuario definir un presupuesto mensual por categoría y ver su progreso de gasto vs límite.

## Acceso
- **Ruta:** `budgets.html`
- **Rol requerido:** `user`
- **Si no hay token:** redirigir a `login.html`

---

## Layout

1. **Header** (navbar común)
2. **Título:** "Mis presupuestos"
3. **Selector de mes/año**
4. **Progreso de presupuestos actuales**
5. **Formulario para agregar/editar presupuesto**
6. **Mensaje de error / éxito**

---

## Selector de mes/año

- **Select mes** (ID: `selectBudgetMonth`) → Enero a Diciembre, valor numérico 1-12
- **Select año** (ID: `selectBudgetYear`) → año actual y próximo año
- Defecto: mes y año actuales
- Al cambiar → recargar la lista de presupuestos del mes seleccionado

---

## Progreso de presupuestos

ID del contenedor: `budgetsProgressContainer`

**Datos:** `GET /budgets/progress?month=X&year=X`

El backend retorna un array de objetos, uno por categoría que tenga presupuesto definido:
```json
[
  {
    "budgetId": 1,
    "category": "Comida",
    "budgetAmount": 20000,
    "spent": 14500,
    "percentage": 72.5
  },
  ...
]
```

Para cada presupuesto, mostrar una **card de progreso** con:
- Nombre de la categoría (con ícono/color de la categoría)
- Barra de progreso (`<progress>` o `<div>` con width dinámico en %)
- Texto: "Gastaste $14.500 de $20.000 (72%)"
- **Color de la barra según porcentaje:**
  - 0–69% → verde
  - 70–89% → amarillo / naranja
  - 90–100% → rojo
  - > 100% → rojo intenso + texto de alerta "¡Superaste el presupuesto!"
- Botones por card:
  - **"Editar"** (ID: `btnEditBudget-{id}`) → abre formulario pre-completado
  - **"Eliminar"** (ID: `btnDeleteBudget-{id}`) → confirma y llama `DELETE /budgets/:id`

**Estado vacío:** "No definiste presupuestos para este mes. ¡Creá uno!"

---

## Formulario para agregar/editar presupuesto

ID: `budgetForm`

Modo **agregar** (defecto):
- Título del formulario: "Nuevo presupuesto"

Modo **editar** (al hacer click en "Editar" de una card):
- Título del formulario: "Editar presupuesto"
- Campos pre-completados

| Campo | Tipo | ID | Validación |
|---|---|---|---|
| Categoría | select | `selectBudgetCategory` | Requerido. En modo editar: deshabilitado (no se puede cambiar la categoría) |
| Monto límite | number | `inputBudgetAmount` | Requerido, > 0 |

El mes y año se toman automáticamente del selector de mes/año activo.

Botón **"Guardar presupuesto"** (ID: `btnSaveBudget`)
Botón **"Cancelar"** (ID: `btnCancelBudget`) → visible solo en modo editar, vuelve al modo agregar

**Flujo agregar:**
- `POST /budgets` con `{ category, amount, month, year }`
- Si error por duplicado (ya existe ese category+month+year) → error: "Ya tenés un presupuesto para esa categoría en este mes"
- Si éxito → recargar progreso, limpiar formulario

**Flujo editar:**
- `PUT /budgets/:id` con `{ amount }`
- Si éxito → recargar progreso, volver a modo agregar

**Flujo eliminar:**
- Confirmación con `window.confirm("¿Eliminar este presupuesto?")` — o modal simple
- `DELETE /budgets/:id`
- Si éxito → recargar progreso

---

## Filtro de categorías en el formulario

En el select de categoría para agregar, **solo mostrar las categorías que NO tienen presupuesto ya definido** para el mes/año seleccionado (para evitar duplicados). Si todas las categorías ya tienen presupuesto → deshabilitar el formulario de agregar y mostrar "Ya tenés presupuesto para todas las categorías de este mes".

---

## Script JS requerido (`budgets.js`)

```js
// Al cargar:
// 1. checkAuth('user')
// 2. Inicializar selector de mes/año con mes actual
// 3. GET /budgets/progress → renderizar cards de progreso
// 4. Configurar formulario agregar/editar
// 5. Configurar cambio de mes/año → recargar datos
// 6. Manejar eliminación
```
