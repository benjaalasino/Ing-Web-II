# 02 — dashboard.html

## Propósito
Panel principal del usuario. Muestra un resumen financiero del mes actual con gráficos y estadísticas.

## Acceso
- **Ruta:** `dashboard.html`
- **Rol requerido:** `user`
- **Si no hay token:** redirigir a `login.html`
- **Si el rol es `advisor`:** redirigir a `advisor-panel.html`

---

## Layout

Estructura de la página:
1. **Header** (navbar común — ver `00-arquitectura-global.md`)
2. **Sección de bienvenida**
3. **Cards de resumen rápido**
4. **Gráfico de torta — gastos por categoría**
5. **Gráfico de barras — gastos por mes (últimos 6 meses)**
6. **Tabla: últimos 5 gastos**
7. **Sección de recomendaciones**

---

## Sección de bienvenida

Texto: "Bienvenido/a, {userName}" (se toma de `localStorage`)
Subtexto: "Resumen de {nombreMesActual} {añoActual}"

---

## Cards de resumen rápido

4 cards en fila (responsivas — en mobile se apilan):

| Card | ID | Dato mostrado | Fuente |
|---|---|---|---|
| Total gastado este mes | `cardTotalMonth` | $XX.XXX,XX | `GET /expenses/stats` → `totalByMonth[mesActual]` |
| Categoría con más gasto | `cardTopCategory` | "Supermercado" | `GET /expenses/stats` → categoría de mayor monto en `totalByCategory` |
| Cantidad de gastos | `cardExpenseCount` | "12 gastos" | Count de `GET /expenses?month=X&year=X` |
| Presupuesto del mes | `cardBudgetStatus` | "70% usado" | `GET /budgets/progress` → suma total gastado / suma total presupuesto |

Mientras cargan los datos: mostrar un placeholder de "Cargando..." en cada card.
Si algún dato no está disponible (ej: no hay presupuestos definidos): mostrar "Sin datos" en esa card.

---

## Gráfico de torta — Gastos por categoría

- **ID del canvas:** `chartCategory`
- **Librería:** Chart.js (cargar desde CDN)
- **Tipo:** `doughnut`
- **Datos:** `GET /expenses/stats` → campo `totalByCategory`
  - El backend retorna: `{ "Comida": 15000, "Transporte": 8000, ... }`
  - Solo mostrar categorías con monto > 0
- **Título del gráfico:** "Gastos por categoría — {mesActual}"
- **Colores:** uno por categoría, consistentes en toda la app (definir paleta fija en CSS/JS)
- **Leyenda:** visible, posicionada debajo del gráfico
- Si no hay datos: ocultar canvas y mostrar mensaje "No hay gastos registrados este mes"

---

## Gráfico de barras — Gastos por mes

- **ID del canvas:** `chartMonthly`
- **Librería:** Chart.js
- **Tipo:** `bar`
- **Datos:** `GET /expenses/stats` → campo `totalByMonth`
  - El backend retorna los últimos 6 meses: `{ "2025-10": 12000, "2025-11": 18000, ... }`
  - Mostrar en orden cronológico ascendente
- **Eje X:** nombre abreviado del mes + año (ej: "Oct 2025")
- **Eje Y:** monto en pesos
- **Color de barras:** color primario de la app
- **Título:** "Evolución de gastos — últimos 6 meses"
- Si no hay datos: mostrar mensaje "No hay suficiente historial para mostrar"

---

## Tabla: últimos 5 gastos

- **ID:** `tableRecentExpenses`
- **Datos:** `GET /expenses?limit=5` (o filtrar los primeros 5 del response ordenado por fecha desc)
- **Columnas:**

| Columna | Campo |
|---|---|
| Fecha | `expense.date` formateada como DD/MM/YYYY |
| Comercio | `expense.commerce` |
| Categoría | `expense.category` (mostrar con badge de color) |
| Monto | `expense.amount` formateado como moneda (ej: $1.500,00) |

- Al hacer click en una fila → navegar a `expenses.html` (no al detalle individual)
- Link debajo de la tabla: "Ver todos los gastos →" → `expenses.html`
- Si no hay gastos: mostrar mensaje "Aún no cargaste ningún gasto. ¡Empezá subiendo tu primer ticket!"
  con botón "Subir ticket" → `upload-ticket.html`

---

## Sección de recomendaciones

- **Datos:** `GET /recommendations` (retorna las últimas 3)
- Cada recomendación se muestra como una card con:
  - Texto de la recomendación
  - Fecha (formateada como DD/MM/YYYY)
  - Indicador: "Del asesor" o "Del sistema" según si tiene `advisorId` o no
- Si no hay recomendaciones: mostrar "Aún no tenés recomendaciones"

---

## Carga de datos al iniciar la página

Todas las llamadas al API se hacen en paralelo con `Promise.all`:

```js
const [stats, recentExpenses, budgetProgress, recommendations] = await Promise.all([
  apiFetch('/expenses/stats'),
  apiFetch('/expenses?limit=5'),
  apiFetch('/budgets/progress'),
  apiFetch('/recommendations?limit=3')
])
```

Si alguna llamada falla → mostrar mensaje de error en la sección correspondiente, no bloquear toda la página.

---

## Script JS requerido (`dashboard.js`)

```js
// Al cargar:
// 1. checkAuth('user')
// 2. Mostrar nombre del usuario en bienvenida
// 3. Llamar todas las APIs en paralelo
// 4. Renderizar cards, gráficos, tabla y recomendaciones
// 5. Manejar errores por sección
```
