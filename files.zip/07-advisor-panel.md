# 07 — advisor-panel.html

## Propósito
Panel principal del asesor financiero. Muestra la lista de todos los usuarios registrados con acceso rápido a sus estadísticas.

## Acceso
- **Ruta:** `advisor-panel.html`
- **Rol requerido:** `advisor`
- **Si no hay token:** redirigir a `login.html`
- **Si el rol es `user`:** redirigir a `dashboard.html`

---

## Layout

1. **Header** (navbar para asesor: Panel | Perfil | Cerrar sesión)
2. **Título:** "Panel del asesor"
3. **Cards de estadísticas globales**
4. **Buscador de usuarios**
5. **Tabla de usuarios**

---

## Cards de estadísticas globales

4 cards en fila (datos agregados de todos los usuarios):

| Card | ID | Dato | Fuente |
|---|---|---|---|
| Total usuarios | `cardTotalUsers` | Cantidad de usuarios registrados | `GET /users` → `.length` |
| Gasto promedio por usuario | `cardAvgExpense` | Promedio del gasto mensual entre todos | `GET /users` + stats (calcular frontend) |
| Usuario con más gastos | `cardTopSpender` | Nombre del usuario que más gastó este mes | Calcular desde los stats de usuarios |
| Categoría más común | `cardTopCategory` | La categoría con más gastos globales | Calcular desde los stats de usuarios |

Si los datos de stats tardan → mostrar "Cargando..." en las cards que lo necesiten.

---

## Buscador de usuarios

- Input text (ID: `searchUsers`, placeholder: "Buscar por nombre o email...")
- Filtrado en tiempo real sobre la tabla (del lado del cliente, sobre los datos ya cargados)
- No hace llamadas adicionales al API

---

## Tabla de usuarios

ID: `tableUsers`

### Columnas

| Columna | Campo | Notas |
|---|---|---|
| Nombre | `user.name` | |
| Email | `user.email` | |
| Fecha de registro | `user.createdAt` | Formato DD/MM/YYYY |
| Gastos este mes | calculado | Suma del mes actual (cargar en segundo plano) |
| Acciones | — | Botón "Ver detalle" |

Botón **"Ver detalle"** por fila → navegar a `advisor-user-detail.html?userId={id}`

### Estado vacío
"No hay usuarios registrados en la plataforma."

---

## Carga de datos

```js
// 1. GET /users → lista de usuarios (solo role='user')
// 2. Renderizar tabla inmediatamente
// 3. En paralelo (sin bloquear la UI): por cada usuario cargar sus stats del mes
//    GET /users/{id}/stats
//    Al llegar cada respuesta → actualizar la celda "Gastos este mes" de esa fila
```

---

## Script JS requerido (`advisor-panel.js`)

```js
// Al cargar:
// 1. checkAuth('advisor')
// 2. GET /users → renderizar tabla y cards básicas
// 3. Cargar stats por usuario en segundo plano
// 4. Configurar buscador en tiempo real
```
