# 08 — advisor-user-detail.html

## Propósito
Vista detallada de un usuario específico desde la perspectiva del asesor. Muestra estadísticas, historial de gastos, patrones de consumo y permite enviar recomendaciones.

## Acceso
- **Ruta:** `advisor-user-detail.html?userId={id}`
- **Rol requerido:** `advisor`
- **Si no hay token:** redirigir a `login.html`
- **Si no hay `userId` en la URL:** redirigir a `advisor-panel.html`
- **El `userId` se obtiene de:** `new URLSearchParams(window.location.search).get('userId')`

---

## Layout

1. **Header** (navbar asesor)
2. **Botón "← Volver al panel"** → `advisor-panel.html`
3. **Cabecera del usuario**
4. **Cards de resumen del usuario**
5. **Gráfico de gastos por categoría**
6. **Gráfico de evolución mensual**
7. **Tabla de gastos del usuario**
8. **Sección de patrones detectados**
9. **Sección de recomendaciones**

---

## Cabecera del usuario

Datos: `GET /users/:id`

Muestra:
- Nombre del usuario (como título H2)
- Email
- Fecha de registro: "Usuario desde DD/MM/YYYY"

---

## Cards de resumen del usuario

Datos: `GET /users/:id/stats`

| Card | Dato |
|---|---|
| Gasto total del mes | Total en el mes actual |
| Gasto promedio mensual | Promedio de todos los meses con gastos |
| Categoría dominante | Categoría con mayor gasto acumulado |
| Gastos inusuales | Cantidad de gastos detectados como anómalos (ver más abajo) |

---

## Gráfico de torta — categorías

- Mismo formato que en `dashboard.html`
- Datos: `GET /users/:id/stats` → `totalByCategory`
- Título: "Distribución de gastos por categoría"

---

## Gráfico de barras — evolución mensual

- Mismo formato que en `dashboard.html`
- Datos: `GET /users/:id/stats` → `totalByMonth` (últimos 6 meses)
- Título: "Evolución mensual de gastos"

---

## Tabla de gastos del usuario

ID: `tableUserExpenses`

Igual en estructura a `expenses.html` pero:
- **Sin botones de editar/eliminar** (el asesor solo puede ver)
- Columnas: Fecha | Comercio | Categoría | Monto
- Mostrar todos los gastos del usuario (sin filtros en esta vista)
- Datos: se toman de `GET /users/:id/stats` o se agrega endpoint `GET /expenses?userId=:id` (backend debe validar que solo un advisor puede usarlo)

---

## Sección de patrones detectados

ID: `patternsSection`

Datos calculados en el **frontend** a partir de los gastos del usuario:

| Patrón | Descripción | Cómo se calcula |
|---|---|---|
| Gasto promedio mensual | Promedio de todos los meses | Suma total / cantidad de meses con gastos |
| Categoría donde más gasta | Categoría con mayor suma | Max de `totalByCategory` |
| Mes con mayor gasto | Mes con más dinero gastado | Max de `totalByMonth` |
| Gastos inusuales | Gastos que superan 3 veces el promedio del usuario | Por cada gasto individual, comparar con `montoPromedio * 3` |

**Visualización de gastos inusuales:**
Si hay gastos inusuales → listarlos en una tabla pequeña con:
- Fecha
- Comercio
- Monto
- Indicador: "⚠ Gasto inusual"

Si no hay gastos inusuales → mostrar "✓ No se detectaron gastos inusuales"

---

## Sección de recomendaciones

ID: `recommendationsSection`

Dividida en dos partes:

### Recomendaciones existentes

Datos: `GET /recommendations?userId=:id` (el backend filtra por userId y el asesor puede ver las de cualquier usuario)

Cada recomendación muestra:
- Texto
- Fecha (DD/MM/YYYY)
- Origen: "Del asesor" o "Del sistema"

Si no hay recomendaciones: "Aún no hay recomendaciones para este usuario."

### Formulario para enviar nueva recomendación

ID: `recommendationForm`

| Campo | Tipo | ID | Validación |
|---|---|---|---|
| Texto | textarea | `inputRecommendationText` | Requerido, mín 10 chars, máx 500 chars |

Botón **"Enviar recomendación"** (ID: `btnSendRecommendation`)

**Flujo:**
1. Validar texto
2. `POST /recommendations` con `{ userId, text }` — el `userId` se toma de la URL, el `advisorId` lo obtiene el backend del JWT
3. Si éxito → agregar la nueva recomendación al listado (sin recargar), limpiar textarea, mostrar `success-message`
4. Si error → mostrar error

---

## Carga de datos al iniciar

```js
const [userData, stats, recommendations] = await Promise.all([
  apiFetch(`/users/${userId}`),
  apiFetch(`/users/${userId}/stats`),
  apiFetch(`/recommendations?userId=${userId}`)
])
```

---

## Script JS requerido (`advisor-user-detail.js`)

```js
// Al cargar:
// 1. checkAuth('advisor')
// 2. Obtener userId de la URL, si no existe → redirigir
// 3. Cargar datos del usuario en paralelo
// 4. Renderizar cabecera, cards, gráficos, tabla
// 5. Calcular y renderizar patrones (frontend)
// 6. Renderizar recomendaciones
// 7. Configurar formulario de nueva recomendación
```
