# 00 — Arquitectura Global y Decisiones Técnicas

## Stack tecnológico

| Capa | Tecnología |
|---|---|
| Frontend | HTML5, CSS3, JavaScript (vanilla) — múltiples archivos `.html` separados |
| Backend | NestJS (Node.js) |
| Base de datos | A definir (compatible con TypeORM: PostgreSQL en Supabase **recomendado**) |
| IA / OCR | A definir — ver sección 4.3. El backend expone siempre el mismo contrato, independientemente del proveedor |
| Auth | JWT almacenado en `localStorage` |
| Deploy Frontend | Netlify / Vercel / GitHub Pages |
| Deploy Backend | Render / Railway |

---

## Estructura de archivos del frontend

```
/frontend
  index.html          ← Landing (ya hecha)
  login.html          ← Login (ya hecho)
  register.html
  dashboard.html
  upload-ticket.html
  expenses.html
  profile.html
  budgets.html
  advisor-panel.html
  advisor-user-detail.html
  /css
    styles.css
  /js
    auth.js           ← helpers de JWT (getToken, saveToken, logout, getRole)
    api.js            ← wrapper de fetch con Authorization header automático
    dashboard.js
    upload-ticket.js
    expenses.js
    profile.js
    budgets.js
    advisor-panel.js
    advisor-user-detail.js
```

---

## Autenticación con JWT

### Flujo general

1. El usuario hace login → el backend devuelve `{ access_token, role, userId, name }`.
2. El frontend guarda en `localStorage`:
   - `token` → el JWT
   - `role` → `"user"` o `"advisor"`
   - `userId` → ID del usuario logueado
   - `userName` → nombre del usuario
3. **Todas las páginas protegidas** ejecutan al inicio de su script JS la función `checkAuth()` (definida en `auth.js`).
4. Si no hay token → redirige a `login.html`.
5. Si el rol no corresponde a la página → redirige a `dashboard.html` (usuario) o `advisor-panel.html` (asesor).

### `auth.js` — funciones requeridas

```js
function getToken()         // Retorna el JWT o null
function getRole()          // Retorna "user" | "advisor" | null
function getUserId()        // Retorna el userId o null
function getUserName()      // Retorna el nombre o null
function saveAuth(data)     // Guarda token, role, userId, userName en localStorage
function logout()           // Limpia localStorage y redirige a login.html
function checkAuth(requiredRole) 
  // Si no hay token → redirige a login.html
  // Si requiredRole está definido y no coincide → redirige según rol
```

### `api.js` — wrapper de fetch

```js
async function apiFetch(endpoint, options = {})
// Agrega automáticamente:
//   Content-Type: application/json
//   Authorization: Bearer <token>
// Base URL tomada de una constante: const API_BASE = "https://TU-BACKEND-URL"
// Si la respuesta es 401 → llama logout() automáticamente
// Retorna el JSON parseado o lanza error con el mensaje del backend
```

---

## Roles de usuario

| Rol | Descripción | Cómo se crea |
|---|---|---|
| `user` | Usuario cliente, gestiona sus propios gastos | Se registra desde `register.html` |
| `advisor` | Asesor financiero, ve todos los usuarios | Se inserta directamente en la base de datos con `role = 'advisor'` |

**Importante:** El campo `role` **no** aparece en el formulario de registro público. Todo usuario que se registra desde la web recibe `role = 'user'` por defecto en el backend.

---

## Modelo de datos (entidades)

### User
```
id          UUID / autoincrement
name        string (requerido)
email       string (único, requerido)
password    string (hash bcrypt, requerido)
role        enum: 'user' | 'advisor'  (default: 'user')
createdAt   datetime
```

### Expense
```
id          UUID / autoincrement
userId      FK → User.id
commerce    string (requerido)
date        date (requerido)
amount      decimal (requerido, > 0)
category    enum: 'Comida' | 'Transporte' | 'Salud' | 'Entretenimiento' | 'Supermercado' | 'Educación' | 'Otros'
description string (opcional)
imageUrl    string (opcional — URL de la imagen del ticket subida)
createdAt   datetime
```

### Budget
```
id          UUID / autoincrement
userId      FK → User.id
category    enum (mismo que Expense.category)
amount      decimal (límite mensual, > 0)
month       integer (1-12)
year        integer
createdAt   datetime
UNIQUE(userId, category, month, year)
```

### Recommendation
```
id          UUID / autoincrement
userId      FK → User.id
advisorId   FK → User.id (null si la generó el sistema)
text        text (requerido)
createdAt   datetime
```

---

## Endpoints del backend (NestJS)

### Auth
```
POST /auth/register     Body: { name, email, password }
POST /auth/login        Body: { email, password }
                        Response: { access_token, role, userId, name }
```

### Users (requiere rol advisor)
```
GET  /users             Retorna lista de todos los usuarios con rol 'user'
GET  /users/:id         Retorna datos básicos de un usuario
GET  /users/:id/stats   Retorna estadísticas de gastos de un usuario específico
```

### Profile (requiere auth, cualquier rol)
```
GET  /profile           Retorna datos del usuario autenticado
PUT  /profile           Body: { name, email, password? }
```

### Expenses (requiere auth)
```
GET    /expenses                  Retorna todos los gastos del usuario autenticado
                                  Query params opcionales: ?category=&month=&year=&commerce=
POST   /expenses                  Body: { commerce, date, amount, category, description?, imageUrl? }
PUT    /expenses/:id              Body: { commerce, date, amount, category, description? }
DELETE /expenses/:id              Elimina un gasto del usuario autenticado
GET    /expenses/stats            Retorna estadísticas agregadas del usuario autenticado
                                  Response: { totalByCategory, totalByMonth, topCommerces, monthlyAverage }
```

### Tickets (requiere auth)
```
POST /tickets/upload    Body: multipart/form-data con campo "image" (jpg/png/webp, max 5MB)
                        Response: { commerce, date, amount }
                        El backend envía la imagen al servicio de IA y retorna los datos extraídos.
                        Si la IA no puede extraer un campo, retorna null para ese campo.
```

### Budgets (requiere auth)
```
GET    /budgets                   Retorna todos los presupuestos del usuario autenticado (mes actual por defecto)
                                  Query params: ?month=&year=
POST   /budgets                   Body: { category, amount, month, year }
PUT    /budgets/:id               Body: { amount }
DELETE /budgets/:id
GET    /budgets/progress          Retorna para cada presupuesto del mes actual: { budget, spent, percentage }
```

### Recommendations (requiere auth)
```
GET    /recommendations           Retorna recomendaciones del usuario autenticado (ordenadas por fecha desc)
POST   /recommendations           Body: { userId, text }  (solo advisors)
```

---

## Guardas de navegación (frontend)

| Página | Rol requerido | Redirección si falla |
|---|---|---|
| register.html | ninguno (si ya hay token → redirigir al dashboard) | — |
| login.html | ninguno (si ya hay token → redirigir al dashboard) | — |
| dashboard.html | `user` | login.html |
| upload-ticket.html | `user` | login.html |
| expenses.html | `user` | login.html |
| profile.html | `user` o `advisor` | login.html |
| budgets.html | `user` | login.html |
| advisor-panel.html | `advisor` | login.html |
| advisor-user-detail.html | `advisor` | login.html |

---

## Navbar / Header común

Todas las páginas protegidas incluyen un header con:
- Logo / nombre de la app (izquierda)
- Links de navegación según rol:
  - **Usuario:** Dashboard | Mis Gastos | Subir Ticket | Presupuestos | Perfil
  - **Asesor:** Panel | Perfil
- Botón "Cerrar sesión" (derecha) → llama `logout()`
- El nombre del usuario logueado se muestra junto al botón de cerrar sesión (se toma de `localStorage`)

---

## Categorías de gasto (lista fija)

Las mismas categorías se usan en todo el sistema (frontend y backend):

```
Comida | Transporte | Salud | Entretenimiento | Supermercado | Educación | Otros
```

No existe opción de crear categorías personalizadas en esta versión.

---

## Manejo de errores (estándar)

El backend responde siempre con:
```json
{ "statusCode": 400, "message": "Descripción del error" }
```

El frontend **siempre** muestra el `message` al usuario dentro de un `<div class="error-message">` visible en la misma página, nunca usando `alert()`.

Los mensajes de éxito se muestran en un `<div class="success-message">`.

Ambos divs están ocultos por defecto (`display: none`) y se muestran/ocultan programáticamente.
