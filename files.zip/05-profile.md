# 05 — profile.html

## Propósito
Permite al usuario (o asesor) ver y editar sus datos personales.

## Acceso
- **Ruta:** `profile.html`
- **Rol requerido:** `user` o `advisor` (cualquier usuario autenticado)
- **Si no hay token:** redirigir a `login.html`

---

## Layout

1. **Header** (navbar común, adaptado al rol del usuario)
2. **Título:** "Mi perfil"
3. **Formulario de perfil**
4. **Sección cambio de contraseña** (separada del formulario principal)
5. **Mensaje de error / éxito**

---

## Carga de datos al iniciar

Al cargar la página → `GET /profile`
Pre-completar el formulario con los datos recibidos:
- `name`
- `email`
- `role` (solo para mostrar, no editable)

---

## Formulario de datos personales

ID: `profileForm`

| Campo | Tipo | ID | Notas |
|---|---|---|---|
| Nombre | text | `inputProfileName` | Editable, requerido, mín 2 chars |
| Email | email | `inputProfileEmail` | Editable, requerido, formato válido |
| Rol | text | `inputProfileRole` | Solo lectura (`disabled`), muestra "Usuario" o "Asesor" |

Botón **"Guardar cambios"** (ID: `btnSaveProfile`) → llama `PUT /profile` con `{ name, email }`

**Flujo:**
- Si éxito → mostrar `success-message`, actualizar `userName` en `localStorage`
- Si error (ej: email ya en uso) → mostrar error

---

## Sección cambio de contraseña

Separada visualmente (con un divisor o acordeón "Cambiar contraseña").

| Campo | Tipo | ID | Validación |
|---|---|---|---|
| Contraseña actual | password | `inputCurrentPassword` | Requerido |
| Nueva contraseña | password | `inputNewPassword` | Requerido, mín 6 chars |
| Confirmar nueva | password | `inputConfirmNewPassword` | Debe coincidir con nueva |

Botón **"Cambiar contraseña"** (ID: `btnChangePassword`) → llama `PUT /profile` con `{ password: newPassword, currentPassword }`

**Nota:** El backend debe verificar `currentPassword` antes de actualizar. Si es incorrecta → responder con error 400 y mensaje "Contraseña actual incorrecta".

**Flujo:**
- Si éxito → limpiar los tres campos, mostrar `success-message`: "Contraseña actualizada"
- Si error → mostrar error en la sección de contraseña

---

## Script JS requerido (`profile.js`)

```js
// Al cargar:
// 1. checkAuth() — sin rol específico, cualquier autenticado
// 2. GET /profile → pre-completar formulario
// 3. Configurar guardado de datos personales
// 4. Configurar cambio de contraseña
```
