# 04 — expenses.html

## Propósito
Listado completo de gastos del usuario con filtros, búsqueda, edición y eliminación.

## Acceso
- **Ruta:** `expenses.html`
- **Rol requerido:** `user`
- **Si no hay token:** redirigir a `login.html`

---

## Layout

1. **Header** (navbar común)
2. **Título:** "Mis gastos"
3. **Barra de filtros**
4. **Resumen de resultados** (ej: "Mostrando 12 gastos · Total: $45.000")
5. **Tabla de gastos**
6. **Modal de edición**
7. **Modal de confirmación de eliminación**
8. **Mensaje de error / éxito**

---

## Barra de filtros

ID del contenedor: `filtersBar`

| Filtro | Tipo | ID | Valores |
|---|---|---|---|
| Categoría | select | `filterCategory` | Todas + lista de categorías |
| Mes | select | `filterMonth` | Todos + Enero…Diciembre |
| Año | select | `filterYear` | Todos + años disponibles (generados dinámicamente desde los gastos) |
| Comercio | text | `filterCommerce` | Input de búsqueda libre |

- Botón **"Filtrar"** (ID: `btnFilter`) → aplica todos los filtros y llama al API
- Botón **"Limpiar"** (ID: `btnClearFilters`) → resetea todos los filtros y recarga la lista completa
- Los filtros se envían como query params: `GET /expenses?category=X&month=X&year=X&commerce=X`

---

## Resumen de resultados

Texto dinámico debajo de los filtros:
- Ejemplo: "Mostrando **12 gastos** · Total: **$45.000,00**"
- El total se calcula sumando los montos de los gastos actualmente visibles (frontend)
- Se actualiza cada vez que se aplican filtros

---

## Tabla de gastos

ID: `tableExpenses`

### Columnas

| Columna | Campo | Notas |
|---|---|---|
| Fecha | `expense.date` | Formato DD/MM/YYYY, ordenable |
| Comercio | `expense.commerce` | Truncar a 30 chars si es muy largo |
| Categoría | `expense.category` | Badge de color (colores fijos por categoría) |
| Monto | `expense.amount` | Formato moneda, alineado a la derecha |
| Acciones | — | Botones editar y eliminar |

### Botones de acción por fila

- **Editar** (ícono lápiz, ID por fila: `btnEdit-{id}`) → abre Modal de edición con los datos de ese gasto
- **Eliminar** (ícono basura, ID por fila: `btnDelete-{id}`) → abre Modal de confirmación

### Ordenamiento

La tabla se puede ordenar por:
- Fecha (defecto: más reciente primero)
- Monto (mayor a menor / menor a mayor)
Al hacer click en el header de la columna → alterna dirección del orden. El ordenamiento es **del lado del cliente** (sobre los datos ya cargados).

### Estado vacío

Si no hay gastos (con o sin filtros):
- Sin filtros aplicados: "Todavía no tenés gastos registrados. ¡Subí tu primer ticket!" con botón → `upload-ticket.html`
- Con filtros aplicados: "No encontramos gastos con esos filtros."

---

## Modal de edición

ID: `modalEdit`

Se muestra como overlay sobre la página. Contiene el mismo formulario que `expenseForm` en `upload-ticket.html` pero **sin** la zona de imagen.

Campos pre-completados con los datos del gasto seleccionado:
- Comercio
- Fecha
- Monto
- Categoría
- Descripción

Botones del modal:
- **"Guardar cambios"** (ID: `btnSaveEdit`) → llama `PUT /expenses/:id`
- **"Cancelar"** (ID: `btnCancelEdit`) → cierra el modal sin guardar

**Flujo de edición:**
1. Al hacer click en "Guardar cambios":
   - Validar campos (mismas reglas que en carga manual)
   - Llamar `PUT /expenses/:id` con los campos modificados
   - Si éxito → cerrar modal, actualizar la fila en la tabla (sin recargar toda la página), mostrar `success-message`
   - Si error → mostrar error dentro del modal

---

## Modal de confirmación de eliminación

ID: `modalDeleteConfirm`

Contenido:
- Texto: "¿Estás seguro que querés eliminar este gasto?"
- Subtexto: "Esta acción no se puede deshacer."
- Botón **"Eliminar"** (ID: `btnConfirmDelete`) → llama `DELETE /expenses/:id`
- Botón **"Cancelar"** (ID: `btnCancelDelete`) → cierra el modal

**Flujo de eliminación:**
1. Al confirmar:
   - Llamar `DELETE /expenses/:id`
   - Si éxito → cerrar modal, remover la fila de la tabla, actualizar resumen de resultados, mostrar `success-message`
   - Si error → mostrar error dentro del modal

---

## Carga de datos

Al cargar la página → `GET /expenses` (sin filtros, todos los gastos del usuario)
Los datos se almacenan en una variable JS (`allExpenses`) y el filtrado/ordenamiento se aplica sobre esa variable localmente cuando es por campos ya disponibles. Solo se vuelve a llamar al API si los filtros cambian.

---

## Script JS requerido (`expenses.js`)

```js
// Al cargar:
// 1. checkAuth('user')
// 2. GET /expenses → almacenar en allExpenses
// 3. Renderizar tabla
// 4. Generar opciones de año dinámicamente desde los datos
// 5. Configurar filtros y ordenamiento
// 6. Configurar modales de edición y eliminación
```
