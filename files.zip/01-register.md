# 01 — register.html

## Propósito
Formulario de registro para nuevos usuarios con rol `user`.

## Acceso
- **Ruta:** `register.html`
- **Rol requerido:** ninguno
- **Si ya hay token válido en localStorage:** redirigir automáticamente a `dashboard.html`

---

## Layout

Página centrada verticalmente y horizontalmente. Fondo consistente con `login.html` y `index.html`.

Componentes en orden:
1. Logo / nombre de la app (clickeable → `index.html`)
2. Título: "Crear cuenta"
3. Formulario de registro
4. Mensaje de error (`<div class="error-message">`, oculto por defecto)
5. Mensaje de éxito (`<div class="success-message">`, oculto por defecto)
6. Link: "¿Ya tenés cuenta? Iniciar sesión" → `login.html`

---

## Formulario

ID del formulario: `registerForm`

| Campo | Tipo | ID | Placeholder | Validación |
|---|---|---|---|---|
| Nombre completo | text | `inputName` | "Tu nombre completo" | Requerido, mínimo 2 caracteres |
| Email | email | `inputEmail` | "tu@email.com" | Requerido, formato email válido |
| Contraseña | password | `inputPassword` | "Mínimo 6 caracteres" | Requerido, mínimo 6 caracteres |
| Confirmar contraseña | password | `inputConfirmPassword` | "Repetí tu contraseña" | Requerido, debe coincidir con `inputPassword` |

Botón de envío:
- Texto: "Registrarse"
- ID: `btnRegister`
- Tipo: `button` (NO `submit` — el envío se maneja con JS)
- Estado deshabilitado mientras se procesa la solicitud

---

## Flujo de interacción

### Validaciones del lado del cliente (antes de llamar al API)

Ejecutar en orden al hacer click en `btnRegister`:

1. Todos los campos son requeridos → mostrar error si alguno está vacío
2. El email debe tener formato válido (usar `input type="email"` + validación JS adicional)
3. La contraseña debe tener mínimo 6 caracteres
4. `inputPassword` y `inputConfirmPassword` deben coincidir → mensaje: "Las contraseñas no coinciden"
5. Si alguna validación falla → mostrar el mensaje en `error-message`, NO llamar al API

### Llamada al API

```
POST /auth/register
Body: { name, email, password }
```

**Durante la llamada:**
- Deshabilitar `btnRegister` y cambiar texto a "Registrando..."

**Si la respuesta es exitosa (201):**
1. Mostrar `success-message` con texto: "¡Cuenta creada exitosamente! Redirigiendo..."
2. Esperar 1500ms
3. Redirigir a `login.html`

**Si la respuesta es error:**
- El backend puede responder:
  - `400` → email ya registrado u otro error de validación
  - `500` → error interno
- Mostrar el `message` del backend en `error-message`
- Re-habilitar `btnRegister` con texto original "Registrarse"

---

## Comportamiento adicional

- Al escribir en cualquier campo, ocultar `error-message` si estaba visible
- Los campos no se limpian si hay error (el usuario puede corregir)
- No existe opción de seleccionar rol en este formulario — el backend asigna `role = 'user'` siempre

---

## Script JS requerido (`register.js`)

```js
// Al cargar la página:
// 1. Importar/usar auth.js
// 2. Si hay token válido → redirigir a dashboard.html

// Listener en btnRegister:
// 1. Leer valores de los campos
// 2. Ejecutar validaciones cliente
// 3. Llamar POST /auth/register
// 4. Manejar éxito y error según flujo descrito
```
