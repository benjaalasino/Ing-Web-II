# 03 — upload-ticket.html

## Propósito
Página para registrar un nuevo gasto. Soporta dos modos: carga manual y carga mediante imagen de ticket (procesada por IA). Ambos modos usan el mismo formulario final.

## Acceso
- **Ruta:** `upload-ticket.html`
- **Rol requerido:** `user`
- **Si no hay token:** redirigir a `login.html`
- **Si el rol es `advisor`:** redirigir a `advisor-panel.html`

---

## Layout

1. **Header** (navbar común)
2. **Título:** "Registrar nuevo gasto"
3. **Selector de modo** (tabs o radio buttons)
4. **Zona de carga de imagen** (visible solo en modo "Ticket")
5. **Formulario de gasto** (siempre visible, puede estar pre-completado por IA)
6. **Mensaje de error** (`<div class="error-message">`, oculto por defecto)
7. **Mensaje de éxito** (`<div class="success-message">`, oculto por defecto)

---

## Selector de modo

Dos opciones presentadas como tabs o botones toggle:
- **"Carga manual"** (ID: `modeManual`) — activo por defecto
- **"Subir ticket"** (ID: `modeTicket`)

Al seleccionar un modo:
- Mostrar/ocultar la zona de imagen según corresponda
- El formulario siempre se mantiene visible

---

## Modo: Subir ticket

### Zona de carga de imagen

- **ID del contenedor:** `ticketUploadArea`
- Área de drag & drop + botón "Seleccionar imagen"
- **Input file** (ID: `inputTicketImage`): acepta `image/jpeg, image/png, image/webp`, máximo 5MB
- Al seleccionar/soltar un archivo:
  1. Validar tipo y tamaño. Si falla → mostrar error, no continuar
  2. Mostrar preview de la imagen seleccionada (tag `<img>` con ID `ticketPreview`)
  3. Mostrar botón "Procesar con IA" (ID: `btnProcessTicket`)

### Botón "Procesar con IA"

- **ID:** `btnProcessTicket`
- Oculto hasta que se seleccione una imagen válida
- Al hacer click:
  1. Cambiar texto del botón a "Procesando..." y deshabilitarlo
  2. Mostrar un spinner/indicador de carga dentro de `ticketUploadArea`
  3. Llamar `POST /tickets/upload` con el archivo como `multipart/form-data` (campo `image`)
  4. **Si respuesta exitosa:**
     - Pre-completar el formulario con los campos retornados:
       - `commerce` → campo `inputCommerce`
       - `date` → campo `inputDate` (formato YYYY-MM-DD para input type="date")
       - `amount` → campo `inputAmount`
     - Si algún campo retorna `null` (IA no pudo extraer) → dejar el campo vacío y resaltar con borde amarillo como indicador visual de "campo no detectado, completar manualmente"
     - Mostrar mensaje: "✓ Ticket procesado. Revisá los datos antes de guardar."
     - Restaurar botón
  5. **Si hay error:**
     - Mostrar mensaje de error
     - Restaurar botón a "Procesar con IA"

**Nota:** La imagen procesada se guarda temporalmente en memoria (no se sube al servidor aún). Se sube junto con el gasto en el paso final.

---

## Formulario de gasto

ID del formulario: `expenseForm`

| Campo | Tipo | ID | Placeholder | Validación |
|---|---|---|---|---|
| Comercio | text | `inputCommerce` | "Ej: Supermercado Día" | Requerido, máx 100 chars |
| Fecha | date | `inputDate` | — | Requerida, no puede ser futura |
| Monto | number | `inputAmount` | "0.00" | Requerido, mayor a 0, máx 2 decimales |
| Categoría | select | `selectCategory` | "Seleccioná una categoría" | Requerida |
| Descripción | textarea | `inputDescription` | "Descripción opcional..." | Opcional, máx 300 chars |

### Opciones del select de categoría
```
-- Seleccioná una categoría --  (valor vacío, deshabilitado)
Comida
Transporte
Salud
Entretenimiento
Supermercado
Educación
Otros
```

### Botón de guardar

- **Texto:** "Guardar gasto"
- **ID:** `btnSaveExpense`
- **Tipo:** `button`
- Deshabilitado mientras se procesa

---

## Flujo al guardar el gasto

1. Validar todos los campos requeridos del formulario
2. Si hay imagen seleccionada (modo ticket):
   - Primero subir la imagen: `POST /tickets/upload` → obtener URL del archivo guardado (si el backend guarda la imagen) — **o** adjuntar la imagen en el mismo request si el backend lo soporta
   - Alternativa simplificada: incluir `imageUrl: null` si el backend no almacena imágenes, solo procesa
3. Llamar `POST /expenses` con:
   ```json
   {
     "commerce": "...",
     "date": "YYYY-MM-DD",
     "amount": 1500.00,
     "category": "Comida",
     "description": "...",
     "imageUrl": null
   }
   ```
4. **Si éxito (201):**
   - Mostrar `success-message`: "¡Gasto registrado exitosamente!"
   - Limpiar formulario y área de imagen
   - Después de 1500ms ofrecer dos opciones:
     - "Registrar otro gasto" → limpiar y reiniciar
     - "Ver mis gastos" → `expenses.html`
5. **Si error:**
   - Mostrar error en `error-message`
   - Restaurar botón

---

## Comportamiento del formulario pre-completado por IA

- Los campos pre-completados son **editables** — el usuario puede corregirlos antes de guardar
- Un campo con borde amarillo indica que la IA no lo detectó y debe completarse manualmente
- Al modificar un campo pre-completado → quitar el borde amarillo

---

## Script JS requerido (`upload-ticket.js`)

```js
// Al cargar:
// 1. checkAuth('user')
// 2. Configurar tabs de modo
// 3. Configurar drag & drop y input file
// 4. Configurar procesamiento de ticket con IA
// 5. Configurar guardado de gasto
// 6. Manejar pre-completado de formulario
```
